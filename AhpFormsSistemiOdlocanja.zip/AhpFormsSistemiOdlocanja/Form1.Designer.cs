﻿
namespace AhpFormsSistemiOdlocanja
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageParametri = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxParametri = new System.Windows.Forms.GroupBox();
            this.btnNaložiTest = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDodajanjeAlternativTab = new System.Windows.Forms.Button();
            this.btnNaprej = new System.Windows.Forms.Button();
            this.btnPrimerjavePoParih = new System.Windows.Forms.Button();
            this.btnIzbrisiNode = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnDodajParam = new System.Windows.Forms.Button();
            this.textBoxParameter = new System.Windows.Forms.TextBox();
            this.dgv_Vektorji = new System.Windows.Forms.DataGridView();
            this.dataGridViewPrimerjava = new System.Windows.Forms.DataGridView();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.tabPageAlternative = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelAlternativa = new System.Windows.Forms.Label();
            this.btnDodajTestAlternative = new System.Windows.Forms.Button();
            this.btnIzračun = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnNaprejAlternativa = new System.Windows.Forms.Button();
            this.btnPrierjavaPoParihAlternative = new System.Windows.Forms.Button();
            this.dgv_UtežiAlternative = new System.Windows.Forms.DataGridView();
            this.dgv_PariAlternative = new System.Windows.Forms.DataGridView();
            this.btnIzbrišiAlternativo = new System.Windows.Forms.Button();
            this.btnDodajAlternativo = new System.Windows.Forms.Button();
            this.textBoxAlternativa = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.listViewAlternative = new System.Windows.Forms.ListView();
            this.tabPageRezultat = new System.Windows.Forms.TabPage();
            this.btnShraniRezultat = new System.Windows.Forms.Button();
            this.btnGraf = new System.Windows.Forms.Button();
            this.lblRezultat = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dgv_Konec = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPageParametri.SuspendLayout();
            this.groupBoxParametri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Vektorji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrimerjava)).BeginInit();
            this.tabPageAlternative.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_UtežiAlternative)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PariAlternative)).BeginInit();
            this.tabPageRezultat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Konec)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageParametri);
            this.tabControl1.Controls.Add(this.tabPageAlternative);
            this.tabControl1.Controls.Add(this.tabPageRezultat);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(-2, -1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1081, 516);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPageParametri
            // 
            this.tabPageParametri.Controls.Add(this.label2);
            this.tabPageParametri.Controls.Add(this.groupBoxParametri);
            this.tabPageParametri.Controls.Add(this.treeView1);
            this.tabPageParametri.Location = new System.Drawing.Point(4, 25);
            this.tabPageParametri.Name = "tabPageParametri";
            this.tabPageParametri.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageParametri.Size = new System.Drawing.Size(1073, 487);
            this.tabPageParametri.TabIndex = 0;
            this.tabPageParametri.Text = "Parametri";
            this.tabPageParametri.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(-1, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Struktura problema";
            // 
            // groupBoxParametri
            // 
            this.groupBoxParametri.BackColor = System.Drawing.Color.LightGray;
            this.groupBoxParametri.Controls.Add(this.btnNaložiTest);
            this.groupBoxParametri.Controls.Add(this.label1);
            this.groupBoxParametri.Controls.Add(this.btnDodajanjeAlternativTab);
            this.groupBoxParametri.Controls.Add(this.btnNaprej);
            this.groupBoxParametri.Controls.Add(this.btnPrimerjavePoParih);
            this.groupBoxParametri.Controls.Add(this.btnIzbrisiNode);
            this.groupBoxParametri.Controls.Add(this.button1);
            this.groupBoxParametri.Controls.Add(this.btnDodajParam);
            this.groupBoxParametri.Controls.Add(this.textBoxParameter);
            this.groupBoxParametri.Controls.Add(this.dgv_Vektorji);
            this.groupBoxParametri.Controls.Add(this.dataGridViewPrimerjava);
            this.groupBoxParametri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxParametri.Location = new System.Drawing.Point(243, 6);
            this.groupBoxParametri.Name = "groupBoxParametri";
            this.groupBoxParametri.Size = new System.Drawing.Size(823, 476);
            this.groupBoxParametri.TabIndex = 1;
            this.groupBoxParametri.TabStop = false;
            this.groupBoxParametri.Text = "Parametri";
            // 
            // btnNaložiTest
            // 
            this.btnNaložiTest.Location = new System.Drawing.Point(742, 11);
            this.btnNaložiTest.Name = "btnNaložiTest";
            this.btnNaložiTest.Size = new System.Drawing.Size(75, 47);
            this.btnNaložiTest.TabIndex = 12;
            this.btnNaložiTest.Text = "Naloži test drevo";
            this.btnNaložiTest.UseVisualStyleBackColor = true;
            this.btnNaložiTest.Click += new System.EventHandler(this.btnNaložiTest_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(424, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Uteži";
            // 
            // btnDodajanjeAlternativTab
            // 
            this.btnDodajanjeAlternativTab.Location = new System.Drawing.Point(681, 451);
            this.btnDodajanjeAlternativTab.Name = "btnDodajanjeAlternativTab";
            this.btnDodajanjeAlternativTab.Size = new System.Drawing.Size(136, 23);
            this.btnDodajanjeAlternativTab.TabIndex = 9;
            this.btnDodajanjeAlternativTab.Text = "Dodajanje alternativ";
            this.btnDodajanjeAlternativTab.UseVisualStyleBackColor = true;
            this.btnDodajanjeAlternativTab.Click += new System.EventHandler(this.btnDodajanjeAlternativTab_Click);
            // 
            // btnNaprej
            // 
            this.btnNaprej.Location = new System.Drawing.Point(156, 72);
            this.btnNaprej.Name = "btnNaprej";
            this.btnNaprej.Size = new System.Drawing.Size(75, 37);
            this.btnNaprej.TabIndex = 8;
            this.btnNaprej.Text = "Naprej";
            this.btnNaprej.UseVisualStyleBackColor = true;
            this.btnNaprej.Click += new System.EventHandler(this.btnNaprej_Click2);
            // 
            // btnPrimerjavePoParih
            // 
            this.btnPrimerjavePoParih.Location = new System.Drawing.Point(15, 72);
            this.btnPrimerjavePoParih.Name = "btnPrimerjavePoParih";
            this.btnPrimerjavePoParih.Size = new System.Drawing.Size(135, 37);
            this.btnPrimerjavePoParih.TabIndex = 7;
            this.btnPrimerjavePoParih.Text = "Primerjave po parih";
            this.btnPrimerjavePoParih.UseVisualStyleBackColor = true;
            this.btnPrimerjavePoParih.Click += new System.EventHandler(this.btnPrimerjavePoParih_Click2);
            // 
            // btnIzbrisiNode
            // 
            this.btnIzbrisiNode.Location = new System.Drawing.Point(346, 42);
            this.btnIzbrisiNode.Name = "btnIzbrisiNode";
            this.btnIzbrisiNode.Size = new System.Drawing.Size(75, 23);
            this.btnIzbrisiNode.TabIndex = 6;
            this.btnIzbrisiNode.Text = "Izbriši";
            this.btnIzbrisiNode.UseVisualStyleBackColor = true;
            this.btnIzbrisiNode.Click += new System.EventHandler(this.btnIzbrisiNode_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(264, 42);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Uredi";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnDodajParam
            // 
            this.btnDodajParam.Location = new System.Drawing.Point(183, 42);
            this.btnDodajParam.Name = "btnDodajParam";
            this.btnDodajParam.Size = new System.Drawing.Size(75, 23);
            this.btnDodajParam.TabIndex = 4;
            this.btnDodajParam.Text = "Dodaj";
            this.btnDodajParam.UseVisualStyleBackColor = true;
            this.btnDodajParam.Click += new System.EventHandler(this.btnDodajParam_Click2);
            // 
            // textBoxParameter
            // 
            this.textBoxParameter.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxParameter.Location = new System.Drawing.Point(15, 42);
            this.textBoxParameter.Name = "textBoxParameter";
            this.textBoxParameter.Size = new System.Drawing.Size(161, 24);
            this.textBoxParameter.TabIndex = 3;
            // 
            // dgv_Vektorji
            // 
            this.dgv_Vektorji.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgv_Vektorji.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Vektorji.Location = new System.Drawing.Point(427, 115);
            this.dgv_Vektorji.Name = "dgv_Vektorji";
            this.dgv_Vektorji.Size = new System.Drawing.Size(390, 330);
            this.dgv_Vektorji.TabIndex = 1;
            // 
            // dataGridViewPrimerjava
            // 
            this.dataGridViewPrimerjava.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewPrimerjava.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewPrimerjava.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridViewPrimerjava.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPrimerjava.Location = new System.Drawing.Point(15, 115);
            this.dataGridViewPrimerjava.Name = "dataGridViewPrimerjava";
            this.dataGridViewPrimerjava.Size = new System.Drawing.Size(406, 329);
            this.dataGridViewPrimerjava.TabIndex = 0;
            this.dataGridViewPrimerjava.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPrimerjava_CellEndEdit);
            // 
            // treeView1
            // 
            this.treeView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeView1.Location = new System.Drawing.Point(3, 33);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(234, 417);
            this.treeView1.TabIndex = 0;
            // 
            // tabPageAlternative
            // 
            this.tabPageAlternative.Controls.Add(this.groupBox1);
            this.tabPageAlternative.Controls.Add(this.label3);
            this.tabPageAlternative.Controls.Add(this.listViewAlternative);
            this.tabPageAlternative.Location = new System.Drawing.Point(4, 25);
            this.tabPageAlternative.Name = "tabPageAlternative";
            this.tabPageAlternative.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAlternative.Size = new System.Drawing.Size(1073, 487);
            this.tabPageAlternative.TabIndex = 1;
            this.tabPageAlternative.Text = "Alternative";
            this.tabPageAlternative.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Silver;
            this.groupBox1.Controls.Add(this.labelAlternativa);
            this.groupBox1.Controls.Add(this.btnDodajTestAlternative);
            this.groupBox1.Controls.Add(this.btnIzračun);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnNaprejAlternativa);
            this.groupBox1.Controls.Add(this.btnPrierjavaPoParihAlternative);
            this.groupBox1.Controls.Add(this.dgv_UtežiAlternative);
            this.groupBox1.Controls.Add(this.dgv_PariAlternative);
            this.groupBox1.Controls.Add(this.btnIzbrišiAlternativo);
            this.groupBox1.Controls.Add(this.btnDodajAlternativo);
            this.groupBox1.Controls.Add(this.textBoxAlternativa);
            this.groupBox1.Location = new System.Drawing.Point(160, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(913, 483);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Alternative";
            // 
            // labelAlternativa
            // 
            this.labelAlternativa.AutoSize = true;
            this.labelAlternativa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAlternativa.Location = new System.Drawing.Point(6, 75);
            this.labelAlternativa.Name = "labelAlternativa";
            this.labelAlternativa.Size = new System.Drawing.Size(140, 18);
            this.labelAlternativa.TabIndex = 12;
            this.labelAlternativa.Text = "Primerjava alternativ";
            // 
            // btnDodajTestAlternative
            // 
            this.btnDodajTestAlternative.Location = new System.Drawing.Point(703, 28);
            this.btnDodajTestAlternative.Name = "btnDodajTestAlternative";
            this.btnDodajTestAlternative.Size = new System.Drawing.Size(113, 46);
            this.btnDodajTestAlternative.TabIndex = 11;
            this.btnDodajTestAlternative.Text = "Dodaj test alternative";
            this.btnDodajTestAlternative.UseVisualStyleBackColor = true;
            this.btnDodajTestAlternative.Click += new System.EventHandler(this.btnDodajTestAlternative_Click);
            // 
            // btnIzračun
            // 
            this.btnIzračun.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzračun.Location = new System.Drawing.Point(831, 19);
            this.btnIzračun.Name = "btnIzračun";
            this.btnIzračun.Size = new System.Drawing.Size(75, 55);
            this.btnIzračun.TabIndex = 10;
            this.btnIzračun.Text = "Izračun in odločitev";
            this.btnIzračun.UseVisualStyleBackColor = true;
            this.btnIzračun.Click += new System.EventHandler(this.btnIzračun_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(472, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Uteži";
            // 
            // btnNaprejAlternativa
            // 
            this.btnNaprejAlternativa.Location = new System.Drawing.Point(394, 67);
            this.btnNaprejAlternativa.Name = "btnNaprejAlternativa";
            this.btnNaprejAlternativa.Size = new System.Drawing.Size(75, 23);
            this.btnNaprejAlternativa.TabIndex = 8;
            this.btnNaprejAlternativa.Text = "Naprej";
            this.btnNaprejAlternativa.UseVisualStyleBackColor = true;
            this.btnNaprejAlternativa.Click += new System.EventHandler(this.btnNaprejAlternativa_Click);
            // 
            // btnPrierjavaPoParihAlternative
            // 
            this.btnPrierjavaPoParihAlternative.Location = new System.Drawing.Point(245, 67);
            this.btnPrierjavaPoParihAlternative.Name = "btnPrierjavaPoParihAlternative";
            this.btnPrierjavaPoParihAlternative.Size = new System.Drawing.Size(143, 23);
            this.btnPrierjavaPoParihAlternative.TabIndex = 7;
            this.btnPrierjavaPoParihAlternative.Text = "Primerjava po parih";
            this.btnPrierjavaPoParihAlternative.UseVisualStyleBackColor = true;
            this.btnPrierjavaPoParihAlternative.Click += new System.EventHandler(this.btnPrierjavaPoParihAlternative_Click);
            // 
            // dgv_UtežiAlternative
            // 
            this.dgv_UtežiAlternative.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_UtežiAlternative.Location = new System.Drawing.Point(475, 96);
            this.dgv_UtežiAlternative.Name = "dgv_UtežiAlternative";
            this.dgv_UtežiAlternative.Size = new System.Drawing.Size(435, 379);
            this.dgv_UtežiAlternative.TabIndex = 6;
            // 
            // dgv_PariAlternative
            // 
            this.dgv_PariAlternative.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_PariAlternative.Location = new System.Drawing.Point(6, 96);
            this.dgv_PariAlternative.Name = "dgv_PariAlternative";
            this.dgv_PariAlternative.Size = new System.Drawing.Size(462, 381);
            this.dgv_PariAlternative.TabIndex = 5;
            this.dgv_PariAlternative.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_PariAlternative_CellEndEdit);
            // 
            // btnIzbrišiAlternativo
            // 
            this.btnIzbrišiAlternativo.Location = new System.Drawing.Point(237, 19);
            this.btnIzbrišiAlternativo.Name = "btnIzbrišiAlternativo";
            this.btnIzbrišiAlternativo.Size = new System.Drawing.Size(75, 26);
            this.btnIzbrišiAlternativo.TabIndex = 4;
            this.btnIzbrišiAlternativo.Text = "Izbriši";
            this.btnIzbrišiAlternativo.UseVisualStyleBackColor = true;
            this.btnIzbrišiAlternativo.Click += new System.EventHandler(this.btnIzbrišiAlternativo_Click);
            // 
            // btnDodajAlternativo
            // 
            this.btnDodajAlternativo.Location = new System.Drawing.Point(156, 19);
            this.btnDodajAlternativo.Name = "btnDodajAlternativo";
            this.btnDodajAlternativo.Size = new System.Drawing.Size(75, 26);
            this.btnDodajAlternativo.TabIndex = 3;
            this.btnDodajAlternativo.Text = "Dodaj";
            this.btnDodajAlternativo.UseVisualStyleBackColor = true;
            this.btnDodajAlternativo.Click += new System.EventHandler(this.btnDodajAlternativo_Click);
            // 
            // textBoxAlternativa
            // 
            this.textBoxAlternativa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAlternativa.Location = new System.Drawing.Point(6, 19);
            this.textBoxAlternativa.Name = "textBoxAlternativa";
            this.textBoxAlternativa.Size = new System.Drawing.Size(144, 26);
            this.textBoxAlternativa.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Seznam alternativ:";
            // 
            // listViewAlternative
            // 
            this.listViewAlternative.HideSelection = false;
            this.listViewAlternative.Location = new System.Drawing.Point(6, 30);
            this.listViewAlternative.Name = "listViewAlternative";
            this.listViewAlternative.Size = new System.Drawing.Size(148, 454);
            this.listViewAlternative.TabIndex = 0;
            this.listViewAlternative.UseCompatibleStateImageBehavior = false;
            // 
            // tabPageRezultat
            // 
            this.tabPageRezultat.Controls.Add(this.btnShraniRezultat);
            this.tabPageRezultat.Controls.Add(this.btnGraf);
            this.tabPageRezultat.Controls.Add(this.lblRezultat);
            this.tabPageRezultat.Controls.Add(this.label6);
            this.tabPageRezultat.Controls.Add(this.label5);
            this.tabPageRezultat.Controls.Add(this.dgv_Konec);
            this.tabPageRezultat.Location = new System.Drawing.Point(4, 25);
            this.tabPageRezultat.Name = "tabPageRezultat";
            this.tabPageRezultat.Size = new System.Drawing.Size(1073, 487);
            this.tabPageRezultat.TabIndex = 2;
            this.tabPageRezultat.Text = "Rezultati";
            this.tabPageRezultat.UseVisualStyleBackColor = true;
            // 
            // btnShraniRezultat
            // 
            this.btnShraniRezultat.Location = new System.Drawing.Point(936, 90);
            this.btnShraniRezultat.Name = "btnShraniRezultat";
            this.btnShraniRezultat.Size = new System.Drawing.Size(99, 55);
            this.btnShraniRezultat.TabIndex = 5;
            this.btnShraniRezultat.Text = "Shrani rezultat";
            this.btnShraniRezultat.UseVisualStyleBackColor = true;
            this.btnShraniRezultat.Click += new System.EventHandler(this.btnShraniRezultat_Click);
            // 
            // btnGraf
            // 
            this.btnGraf.Location = new System.Drawing.Point(936, 151);
            this.btnGraf.Name = "btnGraf";
            this.btnGraf.Size = new System.Drawing.Size(99, 52);
            this.btnGraf.TabIndex = 4;
            this.btnGraf.Text = "Izriši graf";
            this.btnGraf.UseVisualStyleBackColor = true;
            this.btnGraf.Click += new System.EventHandler(this.btnGraf_Click);
            // 
            // lblRezultat
            // 
            this.lblRezultat.AutoSize = true;
            this.lblRezultat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRezultat.Location = new System.Drawing.Point(187, 21);
            this.lblRezultat.Name = "lblRezultat";
            this.lblRezultat.Size = new System.Drawing.Size(0, 20);
            this.lblRezultat.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(27, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 24);
            this.label6.TabIndex = 2;
            this.label6.Text = "Končni rezultat:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 18);
            this.label5.TabIndex = 1;
            this.label5.Text = "Končna tabela";
            // 
            // dgv_Konec
            // 
            this.dgv_Konec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Konec.Location = new System.Drawing.Point(27, 90);
            this.dgv_Konec.Name = "dgv_Konec";
            this.dgv_Konec.Size = new System.Drawing.Size(880, 392);
            this.dgv_Konec.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 515);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPageParametri.ResumeLayout(false);
            this.tabPageParametri.PerformLayout();
            this.groupBoxParametri.ResumeLayout(false);
            this.groupBoxParametri.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Vektorji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrimerjava)).EndInit();
            this.tabPageAlternative.ResumeLayout(false);
            this.tabPageAlternative.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_UtežiAlternative)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PariAlternative)).EndInit();
            this.tabPageRezultat.ResumeLayout(false);
            this.tabPageRezultat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Konec)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageParametri;
        private System.Windows.Forms.TabPage tabPageAlternative;
        private System.Windows.Forms.GroupBox groupBoxParametri;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDodajanjeAlternativTab;
        private System.Windows.Forms.Button btnNaprej;
        private System.Windows.Forms.Button btnPrimerjavePoParih;
        private System.Windows.Forms.Button btnIzbrisiNode;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnDodajParam;
        private System.Windows.Forms.TextBox textBoxParameter;
        private System.Windows.Forms.DataGridView dgv_Vektorji;
        private System.Windows.Forms.DataGridView dataGridViewPrimerjava;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TabPage tabPageRezultat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnNaložiTest;
        private System.Windows.Forms.TextBox textBoxAlternativa;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView listViewAlternative;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnNaprejAlternativa;
        private System.Windows.Forms.Button btnPrierjavaPoParihAlternative;
        private System.Windows.Forms.DataGridView dgv_UtežiAlternative;
        private System.Windows.Forms.DataGridView dgv_PariAlternative;
        private System.Windows.Forms.Button btnIzbrišiAlternativo;
        private System.Windows.Forms.Button btnDodajAlternativo;
        private System.Windows.Forms.Button btnIzračun;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnDodajTestAlternative;
        private System.Windows.Forms.Label labelAlternativa;
        private System.Windows.Forms.Button btnShraniRezultat;
        private System.Windows.Forms.Button btnGraf;
        private System.Windows.Forms.Label lblRezultat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgv_Konec;
    }
}

