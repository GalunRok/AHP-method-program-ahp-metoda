﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AhpFormsSistemiOdlocanja.AHP
{
    public class Parameter
    {
        public string Ime { get; set; }
        public double Utez { get; set; }
        public double Koristnost { get; set; }
        public int Level { get; set; }
        public Queue<Parameter> Starsi { get; set; }
        public List<Parameter> Otroci { get; set; }

        public bool JeKoren
        {
            get
            {
                if (Level == 1)
                { return true; }
                else
                { return false; }
            }
        }
            
        public bool getParametriOtrok(List<Parameter> VsiParametri)
        {
            List<Parameter> otroci = new List<Parameter>();
            foreach(string imeOtroka in this.otrociString)
            {
                Parameter najdenOtrok = VsiParametri.FirstOrDefault(x => x.Ime == imeOtroka);
                if(najdenOtrok != default)
                {
                    otroci.Add(najdenOtrok);
                }
                else
                {
                    return false;
                }
            }
            Otroci = otroci;
            return true;
        }
        public List<string> otrociString { get; set; }
        public bool ImaStarse
        {
            get
            {
                if(Starsi != null)
                {
                    return true;
                }
                return false;
            }
        }
        public bool ImaOtroke
        {
            get
            {
                if(otrociString != null)
                {
                    return true;
                }
                return false;
            }
        }
    }
}
