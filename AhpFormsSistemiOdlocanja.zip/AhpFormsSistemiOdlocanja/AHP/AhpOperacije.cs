﻿using MathNet.Numerics.LinearAlgebra;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AhpFormsSistemiOdlocanja.AHP
{
    class AhpOperacije
    {
        public DataTable GetTable(List<string> tData, Matrix<double> matrix)
        {
            DataTable tabela = new DataTable();
            for(int i =0;i < tData.Count; i++)
            {
                tabela.Columns.Add();
            }
            for (int i = 0; i < tData.Count; i++)
            {
                DataRow vrstica = tabela.NewRow();
                for(int u = 0; u < tData.Count; u++)
                {
                    vrstica[u] = matrix[i, u];
                }
                tabela.Rows.Add(vrstica);
            }
            return tabela;
        }
        public void IzrisiTabelo(DataTable data, DataGridView dataGridView, List<string> parametri)
        {
            dataGridView.DataSource = data;
            for (int i = 0; i < parametri.Count; i++)
            {
                dataGridView.Rows[i].HeaderCell.Value = parametri[i];
                dataGridView.Columns[i].HeaderCell.Value = parametri[i];
            }
        }
        public void PrimerjavaPoParih(DataGridView dataGridView)
        {
            double rezultat;
            for(int i = 0; i < dataGridView.Rows.Count-1; i++)
            {
                for (int j = 0; j < dataGridView.Columns.Count; j++) 
                {
                    if (double.TryParse(dataGridView.Rows[i].Cells[j].Value.ToString(), out double vrednost))
                    {
                        if (vrednost != 1)
                        {
                            rezultat = 1 / vrednost;
                            if (rezultat < 1)
                            {
                                dataGridView.Rows[j].Cells[i].Value = Math.Round(rezultat, 3);
                            }
                            else
                            {
                                 dataGridView.Rows[j].Cells[i].Value = Math.Round(rezultat,2);
                            }
                        }
                    }
                }
            }
        }
        public List<double> SestejStolpce(DataGridView dataGridView)
        {
            List<double> sestevekStolpca = new List<double>();
            double sestevek = 0;
            int counter = 0;
            for(int i =0; i < dataGridView.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dataGridView.Columns.Count; j++)
                {
                    sestevek = sestevek + double.Parse(dataGridView.Rows[j].Cells[i].Value.ToString());
                }
                dataGridView.Rows[dataGridView.Rows.Count - 1].Cells[i].Value = sestevek;
                sestevekStolpca.Add(sestevek);
                counter++;
                sestevek = 0;
            }
            dataGridView.Rows[dataGridView.Rows.Count - 1].HeaderCell.Value = "Skupaj";
            return sestevekStolpca;
        }
        public Matrix<double> NormalizacijaMatrike(DataGridView dataGridView, List<double> sestevekStolpca)
        {
            Matrix<double> normaliziranaMatrika = Matrix<double>.Build.Dense(dataGridView.ColumnCount, dataGridView.RowCount - 1);
            for(int i = 0; i < dataGridView.Columns.Count; i++)
            {
                for(int j =0;j<dataGridView.Rows.Count - 1; j++)
                {
                    normaliziranaMatrika[j, i] = Math.Round(double.Parse(dataGridView.Rows[j].Cells[i].Value.ToString()) / sestevekStolpca[i], 3);
                }
            }
            return normaliziranaMatrika;
        }
        public Vector<double> GetUteziParametrov(DataGridView dataGridView)
        {
            List<string> parametri = new List<string>();
            Vector<double> uteziParam = Vector<double>.Build.Dense(dataGridView.Rows.Count - 1);
            int stevecVrstic = dataGridView.Columns.Count;
            double sestevek = 0;
            
            for(int i = 0; i < dataGridView.Rows.Count - 1; i++)
            {
                for(int j = 0; j < dataGridView.Columns.Count; j++)
                {
                    sestevek += Convert.ToDouble(dataGridView.Rows[i].Cells[j].Value);
                }
                uteziParam[i] = Math.Round(sestevek / stevecVrstic, 2);
                sestevek = 0;
            }
            return uteziParam;
        }
        
    }
}
