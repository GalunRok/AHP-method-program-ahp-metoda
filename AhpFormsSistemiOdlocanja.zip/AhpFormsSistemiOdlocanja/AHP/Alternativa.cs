﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AhpFormsSistemiOdlocanja
{
    class Alternativa
    {
        public string Ime { get; set; }
        public double Rezultat { get; set; }
        public double Koristnost { get; set; }
        public Dictionary<string, double> KoristnostNaParameter = new Dictionary<string, double>();

        
    }
}
