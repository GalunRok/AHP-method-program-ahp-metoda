﻿using AhpFormsSistemiOdlocanja.AHP;
using MathNet.Numerics.LinearAlgebra;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace AhpFormsSistemiOdlocanja
{
    public partial class Form1 : Form
    {
        int števecAltPrimerjava = 0;
        static List<Parameter> vsiParametri = new List<Parameter>();
        List<TreeNodeCollection> starsiListTree = new List<TreeNodeCollection>();
        List<Parameter> starsiParam = new List<Parameter>();
        List<Parameter> otrociParam = new List<Parameter>();
        List<Alternativa> alternativeObjekti = new List<Alternativa>();
        
        int maxGlobina = 1;
        Dictionary<int, List<Parameter>> StarsiParamPoLevelih = new Dictionary<int, List<Parameter>>();
        int stevecStarsevZaPrimerjavo = 0;

        AhpOperacije ahp = new AhpOperacije();
        public List<string> parametriStringSeznam = new List<string>();
        List<string> alternativeString = new List<string>();
        TreeNode koren = new TreeNode("cilj");
        Vector<double> UtezParameter;

        Matrix<double> alternativeMatrika;
        Matrix<double> parametriMatrika;
        Matrix<double> normalizranaMatrika;

        List<double> alternativeStolpecSum= new List<double>();

        List<string> parametriZaPrimerjavo;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            treeView1.Nodes.Add(koren);
            listViewAlternative.View = View.List;
        }
        private void btnDodajParam_Click2(object sender, EventArgs e)
        {
            if (textBoxParameter.Text != "" && NodeObstaja(textBoxParameter.Text, treeView1.Nodes) == false)
            {
                string parameterIme = textBoxParameter.Text;
                if (treeView1.SelectedNode == null)
                {
                    treeView1.Nodes[0].Nodes.Add(parameterIme);
                }
                else
                {
                    treeView1.SelectedNode.Nodes.Add(parameterIme);
                }
                treeView1.ExpandAll();
                treeView1.SelectedNode = null;
                textBoxParameter.Clear();
            }
        }

        private bool NodeObstaja(string iskalnaBeseda, TreeNodeCollection treeNodeCollection)
        {
            foreach(TreeNode node in treeNodeCollection)
            {
                if(node.Text == iskalnaBeseda)
                {
                    return true;
                }
                if(node.Nodes.Count > 0)
                {
                    bool rezultat = NodeObstaja(iskalnaBeseda, node.Nodes);
                    if(rezultat)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        private TreeNode poisciNode(string iskalnaBeseda, TreeNodeCollection treeNodeCollection)
        {
            foreach(TreeNode node in treeNodeCollection)
            {
                if(node.Text == iskalnaBeseda)
                {
                    return node;
                }
                if(node.Nodes.Count > 0)
                {
                    var rezultat = poisciNode(iskalnaBeseda, node.Nodes);
                    if(rezultat != null)
                    {
                        return rezultat;
                    }
                }
            }
            return null;
        }

        private void btnIzbrisiNode_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode != null && treeView1.SelectedNode.Text != koren.Text)
            {
                treeView1.SelectedNode.Remove();
            }
        }
        /*private void IzbrisiParam(Parameter paramIzbris)
        {
            string paramNaziv = paramIzbris.Ime;
            if (paramIzbris.ImaOtroke)
            {
                List<Parameter> otroci = paramIzbris.Otroci;
                foreach (Parameter parameter in otroci)
                {
                    IzbrisiParam(parameter);
                }
            }
            parameterObjekt.Remove(paramNaziv);
            parameterList.Remove(paramIzbris);

        }*/
        private void btnPrimerjavePoParih_Click2(object sender, EventArgs e)
        {
            vsiParametri.Clear();
            starsiParam.Clear();
            StarsiParamPoLevelih.Clear();
            btnNaprej.Enabled = true;
            btnNaprej.Show();

            GetVsiParam(treeView1.Nodes, 0);
            starsiParam = vsiParametri.Where(x => x.ImaOtroke == true).ToList();
            for (int i = 1; i <= maxGlobina; i++)
            {
                StarsiParamPoLevelih.Add(i, starsiParam.Where(x => x.Level == i).ToList());
            }
            stevecStarsevZaPrimerjavo = 1;
            try
            {
                maxGlobina = starsiParam.Max(x => x.Level);
            }
            catch
            {
                MessageBox.Show("Drevo nima podelementov!");
                return;
            }
            parametriZaPrimerjavo = new List<string>();
            Parameter koren = starsiParam.FirstOrDefault(x => x.JeKoren);
            koren.getParametriOtrok(vsiParametri);
            parametriZaPrimerjavo = koren.otrociString;
            parametriMatrika = Matrix<double>.Build.Dense(parametriZaPrimerjavo.Count, parametriZaPrimerjavo.Count, 1);
            DataTable data = ahp.GetTable(parametriZaPrimerjavo, parametriMatrika);
            ahp.IzrisiTabelo(data, dataGridViewPrimerjava, parametriZaPrimerjavo);
            for (int i = 0; i < dataGridViewPrimerjava.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridViewPrimerjava.Columns.Count; j++)
                {
                    if (i == j)
                    {
                        dataGridViewPrimerjava.Rows[i].Cells[j].ReadOnly = true;
                        dataGridViewPrimerjava.Rows[i].Cells[j].Style.BackColor = Color.LightGray;
                    }
                }
            }
            dataGridViewPrimerjava.TopLeftHeaderCell.Value = koren.Ime;
        }

        private void dataGridViewPrimerjava_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (double.TryParse(dataGridViewPrimerjava.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString(), out double vrednost) == false)
            {
                dataGridViewPrimerjava.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.Red;
                MessageBox.Show("Napačni vnos");
            }
            else
            { 
                dataGridViewPrimerjava.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.White;
                ahp.PrimerjavaPoParih(dataGridViewPrimerjava);
                alternativeStolpecSum = ahp.SestejStolpce(dataGridViewPrimerjava);
                normalizranaMatrika = ahp.NormalizacijaMatrike(dataGridViewPrimerjava, alternativeStolpecSum);
                DataTable NormaliziranaTabela = ahp.GetTable(parametriZaPrimerjavo, normalizranaMatrika);
                ahp.IzrisiTabelo(NormaliziranaTabela, dgv_Vektorji, parametriZaPrimerjavo);
                UtezParameter = ahp.GetUteziParametrov(dgv_Vektorji);
                NormaliziranaTabela.Columns.Add("Uteži");
                int index = NormaliziranaTabela.Columns.Count - 1;

                ahp.IzrisiTabelo(NormaliziranaTabela, dgv_Vektorji, parametriZaPrimerjavo);
                
                int index2 = dgv_Vektorji.Columns.Count-1;
                for(int i = 0; i < dgv_Vektorji.Rows.Count-1; i++)
                {
                    dgv_Vektorji.Rows[i].Cells[index2].Value = UtezParameter[i];
                    string imeParam =  dgv_Vektorji.Rows[i].HeaderCell.Value.ToString();
                    vsiParametri.FirstOrDefault(x => x.Ime == imeParam).Utez = UtezParameter[i];
                    dgv_Vektorji.Rows[i].Cells[index2].Style.BackColor = Color.LightBlue;
                }
            }
           
        }
        private void btnNaprej_Click2(object sender, EventArgs e)
        {
            if(stevecStarsevZaPrimerjavo < starsiParam.Count && stevecStarsevZaPrimerjavo !=0)
            {
                btnNaprej.Enabled = true;
                btnNaprej.Show();
                parametriZaPrimerjavo = new List<string>();
                parametriZaPrimerjavo = starsiParam[stevecStarsevZaPrimerjavo].otrociString;
                dgv_Vektorji.DataSource = null;
                dgv_Vektorji.Rows.Clear();
                dgv_Vektorji.Columns.Clear();
                dgv_Vektorji.Update();

                parametriMatrika = Matrix<double>.Build.Dense(parametriZaPrimerjavo.Count, parametriZaPrimerjavo.Count, 1);
                DataTable data = ahp.GetTable(parametriZaPrimerjavo, parametriMatrika);
                
                ahp.IzrisiTabelo(data, dataGridViewPrimerjava, parametriZaPrimerjavo);
                for (int i = 0; i < dataGridViewPrimerjava.Rows.Count; i++)
                {
                    
                    for (int j = 0; j < dataGridViewPrimerjava.Columns.Count; j++)
                    {
                        if (i == j)
                        {
                            dataGridViewPrimerjava.Rows[i].Cells[j].ReadOnly = true;
                            dataGridViewPrimerjava.Rows[i].Cells[j].Style.BackColor = Color.LightGray;
                        }
                    }
                }
                dataGridViewPrimerjava.TopLeftHeaderCell.Value = starsiParam[stevecStarsevZaPrimerjavo].Ime;
                stevecStarsevZaPrimerjavo++;
                
            }
            else
            {
                btnNaprej.Enabled = false;
                btnNaprej.Hide();
                MessageBox.Show("Vse uteži so izračunane, sledi dodajanje parametrov.");
            }
        }
        
        public static void GetVsiParam(TreeNodeCollection nodes, int globina)
        {
            if(globina == 0)
            {
                vsiParametri.Clear();
            }
            globina++;
            foreach (TreeNode node in nodes)
            {          
                vsiParametri.Add(new Parameter {Ime= node.Text, Level = globina});
                if(node.Nodes.Count > 0)
                {
                    List<string> otroci = new List<string>();
                    foreach(TreeNode otrok in node.Nodes)
                    {
                        otroci.Add(otrok.Text);
                    }
                    vsiParametri.Last().otrociString = otroci.ToList();
                }
                GetVsiParam(node.Nodes, globina);
            }
        }

        public void GetStarsiTree(TreeNodeCollection nodes, int globina)
        {
            globina++;
            foreach(TreeNode node in nodes)
            {
                if (node.Nodes.Count > 0)
                {
                    starsiListTree.Add(node.Nodes);
                    List<string> imenaOtrok = new List<string>();
                    foreach(TreeNode otrok in node.Nodes)
                    {
                        imenaOtrok.Add(otrok.Text);
                    }
                    starsiParam.Add(new Parameter { Ime = node.Text, Level = globina, otrociString = imenaOtrok});
                  
                    GetStarsiTree(node.Nodes, globina);
                } 
            }
        }
        /*private void getVsiParambtn_Click(object sender, EventArgs e)
        {
            vsiParametri.Clear();
            GetVsiParam(treeView1.Nodes, 0);
            List<Parameter> parametri = vsiParametri;
        }
        */
        private void btnNaložiTest_Click(object sender, EventArgs e)
        {
            treeView1.Nodes.Clear();
            treeView1.Nodes.Add("cilj");
            treeView1.Nodes[0].Nodes.Add("Tehnika","Tehnika");
            treeView1.Nodes[0].Nodes.Add("Cena");
            
            treeView1.Nodes[0].Nodes["Tehnika"].Nodes.Add("procesor");
            treeView1.Nodes[0].Nodes["Tehnika"].Nodes.Add("pomnilnik", "pomnilnik");
            treeView1.Nodes[0].Nodes["Tehnika"].Nodes.Add("zaslon");
            treeView1.Nodes[0].Nodes["Tehnika"].Nodes["pomnilnik"].Nodes.Add("RAM");
            treeView1.Nodes[0].Nodes["Tehnika"].Nodes["pomnilnik"].Nodes.Add("disk");
            treeView1.ExpandAll();
        }

        private void btnDodajanjeAlternativTab_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(1);
        }

        private void btnDodajAlternativo_Click(object sender, EventArgs e)
        {
            if(textBoxAlternativa.Text != "" && AlternativaObstaja(textBoxAlternativa.Text))
            {
                listViewAlternative.Items.Add(textBoxAlternativa.Text);
                textBoxAlternativa.Clear();
            }
        }
        public bool AlternativaObstaja(string text)
        {
            foreach(ListViewItem lvi in listViewAlternative.Items)
            {
                if(lvi.Text == text)
                {
                    return false;
                }
            }
            return true;
        }

        private void btnIzbrišiAlternativo_Click(object sender, EventArgs e)
        {
            listViewAlternative.SelectedItems.Clear();
        }
        private static List<Parameter> getOtrociParam()
        {
            return vsiParametri.Where(x => x.ImaOtroke == false).ToList();
        }
        private void btnPrierjavaPoParihAlternative_Click(object sender, EventArgs e)
        {
            otrociParam.Clear();
            alternativeObjekti.Clear();
            otrociParam = getOtrociParam();
            alternativeString.Clear();
            števecAltPrimerjava = 0;

            try
            {
                labelAlternativa.Text = "Primerjava gleda na: " + otrociParam[števecAltPrimerjava].Ime;
            }
            catch
            {
                MessageBox.Show("Najprej dodajte parametre.");
                return;
                   
            }
            foreach(ListViewItem item in listViewAlternative.Items)
            {
                alternativeObjekti.Add(new Alternativa { Ime = item.Text });
            }
            alternativeMatrika = Matrix<double>.Build.Dense(alternativeObjekti.Count, alternativeObjekti.Count, 1);
            foreach (Alternativa a in alternativeObjekti) 
            {
                alternativeString.Add(a.Ime);
            }
            DataTable data = ahp.GetTable(alternativeString, alternativeMatrika);
            ahp.IzrisiTabelo(data, dgv_PariAlternative, alternativeString);

            for(int i = 0; i < dgv_PariAlternative.Rows.Count; i++)
            {
                for (int j = 0; j < dgv_PariAlternative.Columns.Count; j++)
                {
                    if (i == j)
                    {
                        dgv_PariAlternative.Rows[i].Cells[j].ReadOnly = true;
                        dgv_PariAlternative.Rows[i].Cells[j].Style.BackColor = Color.LightGray;
                    }
                }
            }
            števecAltPrimerjava++;
        }

        private void btnDodajTestAlternative_Click(object sender, EventArgs e)
        {
            listViewAlternative.Items.Add("Fujitsu");
            listViewAlternative.Items.Add("Asus");
            listViewAlternative.Items.Add("HP");
            listViewAlternative.Items.Add("Toshiba");
        }

        private void dgv_PariAlternative_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (double.TryParse(dgv_PariAlternative.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString(), out double vrednost) == false)
            {
                dgv_PariAlternative.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.Red;
                MessageBox.Show("Napačni vnos");
            }
            else
            {
                dgv_PariAlternative.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.White;
                ahp.PrimerjavaPoParih(dgv_PariAlternative);
                alternativeStolpecSum = ahp.SestejStolpce(dgv_PariAlternative);
                normalizranaMatrika = ahp.NormalizacijaMatrike(dgv_PariAlternative, alternativeStolpecSum);
                DataTable NormaliziranaTabela = ahp.GetTable(alternativeString, normalizranaMatrika);

                ahp.IzrisiTabelo(NormaliziranaTabela, dgv_UtežiAlternative, alternativeString);
                UtezParameter = ahp.GetUteziParametrov(dgv_UtežiAlternative);
                NormaliziranaTabela.Columns.Add("Uteži");
                int index = NormaliziranaTabela.Columns.Count - 1;

                ahp.IzrisiTabelo(NormaliziranaTabela, dgv_UtežiAlternative, alternativeString);

                int index2 = dgv_UtežiAlternative.Columns.Count - 1;
                for (int i = 0; i < dgv_UtežiAlternative.Rows.Count - 1; i++)
                {
                    dgv_UtežiAlternative.Rows[i].Cells[index2].Value = UtezParameter[i];
                    string imealt = dgv_UtežiAlternative.Rows[i].HeaderCell.Value.ToString();
                   
                    if(alternativeObjekti.FirstOrDefault(x => x.Ime == imealt).KoristnostNaParameter.TryGetValue(otrociParam[števecAltPrimerjava-1].Ime, out vrednost))
                    {
                        alternativeObjekti.FirstOrDefault(x => x.Ime == imealt).KoristnostNaParameter[otrociParam[števecAltPrimerjava-1].Ime] = UtezParameter[i];
                    }
                    else
                    {
                        alternativeObjekti.FirstOrDefault(x => x.Ime == imealt).KoristnostNaParameter.Add(otrociParam[števecAltPrimerjava-1].Ime,UtezParameter[i]);
                    }
                    dgv_UtežiAlternative.Rows[i].Cells[index2].Style.BackColor = Color.LightBlue;
                }
            }
        }

        private void btnNaprejAlternativa_Click(object sender, EventArgs e)
        {
            if (števecAltPrimerjava <  otrociParam.Count && števecAltPrimerjava != 0)
            {
                btnNaprejAlternativa.Enabled = true;
                btnNaprejAlternativa.Show();
                parametriZaPrimerjavo = new List<string>();
                dgv_UtežiAlternative.DataSource = null;
                dgv_UtežiAlternative.Rows.Clear();
                dgv_UtežiAlternative.Columns.Clear();
                dgv_UtežiAlternative.Update();

                labelAlternativa.Text = "Primerjava gleda na: " + otrociParam[števecAltPrimerjava].Ime;
                alternativeMatrika = Matrix<double>.Build.Dense(alternativeObjekti.Count, alternativeObjekti.Count, 1);

                DataTable data = ahp.GetTable(alternativeString, alternativeMatrika);
                ahp.IzrisiTabelo(data, dgv_PariAlternative, alternativeString);

                for (int i = 0; i < dgv_PariAlternative.Rows.Count; i++)
                {
                    for (int j = 0; j < dgv_PariAlternative.Columns.Count; j++)
                    {
                        if (i == j)
                        {
                            dgv_PariAlternative.Rows[i].Cells[j].ReadOnly = true;
                            dgv_PariAlternative.Rows[i].Cells[j].Style.BackColor = Color.LightGray;
                        }
                    }
                }
                števecAltPrimerjava++;
            }
            else
            {
                btnNaprejAlternativa.Enabled = false;
                btnNaprejAlternativa.Hide();
                MessageBox.Show("Vse uteži so izračunane, sledi Končni izračun.");
            }
        }

        private void btnIzračun_Click(object sender, EventArgs e)
        {
            List<Parameter> starsiOdNajglobjiDoRoot = starsiParam.OrderByDescending(x => x.Level).ToList();

            for(int i = 0; i < starsiOdNajglobjiDoRoot.Count; i++)
            {
                for(int j = 0; j < alternativeObjekti.Count; j++)
                {
                    string parameterIme = starsiOdNajglobjiDoRoot[i].Ime;
                    double koristnost = 0;
                    if (starsiOdNajglobjiDoRoot[i].getParametriOtrok(vsiParametri))
                    {
                        foreach (Parameter otrok in starsiOdNajglobjiDoRoot[i].Otroci)
                        {
                            koristnost += otrok.Utez * alternativeObjekti[j].KoristnostNaParameter[otrok.Ime];
                        }
                        alternativeObjekti[j].KoristnostNaParameter.Add(parameterIme, Math.Round(koristnost,3));
                    }
                    if(i+1 == starsiOdNajglobjiDoRoot.Count)
                    {
                        alternativeObjekti[j].Rezultat = koristnost;
                    }
                }
            }
            Alternativa zmaga = alternativeObjekti.FirstOrDefault(x => x.Rezultat == alternativeObjekti.Max(m => m.Rezultat)); ;
            lblRezultat.Text = zmaga.Ime +" končna ocena: " + zmaga.Rezultat;
            
            Matrix<double> rezultatiMatrika = Matrix<double>.Build.Dense(vsiParametri.Count, alternativeObjekti.Count, 1);
            for(int i = 0; i < rezultatiMatrika.ColumnCount; i++)
            {
                for (int j = 0; j < rezultatiMatrika.RowCount;j++)
                {
                    rezultatiMatrika[j, i] = alternativeObjekti[i].KoristnostNaParameter[vsiParametri[j].Ime];
                }
            }
            DataTable data = new DataTable();
            for (int i = 0; i < rezultatiMatrika.ColumnCount; i++) 
            {
                data.Columns.Add();
            }
            for(int i = 0; i < rezultatiMatrika.RowCount; i++)
            {
                DataRow vrstica = data.NewRow();
                for(int j = 0; j < rezultatiMatrika.ColumnCount; j++)
                {
                    vrstica[j] = rezultatiMatrika[i,j];
                }
                data.Rows.Add(vrstica);
            }
            dgv_Konec.DataSource = data;
            for (int i = 0; i < alternativeObjekti.Count; i++)
            {
                dgv_Konec.Columns[i].HeaderCell.Value = alternativeObjekti[i].Ime;
            }
            for(int i = 0; i < vsiParametri.Count; i++)
            {
                dgv_Konec.Rows[i].HeaderCell.Value = vsiParametri[i].Ime;
            }
            tabControl1.SelectTab(2);
        }

        private void btnShraniRezultat_Click(object sender, EventArgs e)
        {
            string koncniRezultati = "";
            foreach (var item in alternativeObjekti)
            {
                koncniRezultati += item.Ime + ":  " + item.Rezultat.ToString() + "\n";
            }
            MessageBox.Show(koncniRezultati);

            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "text | .txt";
            save.Title = "Shrani rezultate";
            save.ShowDialog();
            if (save.FileName != "")
            {
                File.WriteAllText(save.FileName, koncniRezultati);
            }
        }

        private void btnGraf_Click(object sender, EventArgs e)
        {
            Chart graf = new Chart() { Dock = DockStyle.Fill }; ;

            var grafForm = new Form
            {
                Visible = false,
                TopMost = true,
                Width = 1000,
                Height = 800
            };
            var chartArea = new ChartArea("graf");
            chartArea.AxisY.Title = "Vrednost";
            chartArea.AxisX.Title = "Alternativa";
            graf.ChartAreas.Add(chartArea);
            graf.Legends.Add("legend1");

            graf.Titles.Add("Primerjava alternativ");

            for (int i = 0; i < alternativeObjekti.Count; i++)
            {
                graf.Series.Add(alternativeObjekti[i].Ime);
                graf.Series[alternativeObjekti[i].Ime].LegendText = alternativeObjekti[i].Ime;
                graf.Series[alternativeObjekti[i].Ime].ChartType = SeriesChartType.Bar;
                graf.Series[alternativeObjekti[i].Ime].IsValueShownAsLabel = true;
                graf.Series[alternativeObjekti[i].Ime].Points.AddXY(alternativeObjekti[i].Ime, alternativeObjekti[i].Rezultat);
            }
            grafForm.Controls.Add(graf);
            grafForm.ShowDialog();

            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Slika | .png";
            save.ShowDialog();

            if (save.FileName != "")
            {
                graf.SaveImage(save.FileName, System.Drawing.Imaging.ImageFormat.Png);
            }
        }
    }
}
